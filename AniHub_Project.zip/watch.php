<?php
require __DIR__.'/config.php';
$id=(int)($_GET['id']??0); $s=$db->prepare("SELECT e.*,a.title anime FROM episodes e JOIN anime a ON a.id=e.anime_id WHERE e.id=?");$s->execute([$id]);$ep=$s->fetch(PDO::FETCH_ASSOC);
if(!$ep) exit('Episode not found');
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Watch - <?=e($ep['anime'])?></title><link rel="stylesheet" href="assets/style.css"></head><body>
<header><a class="logo" href="index.php">ANI<span>HUB</span></a><nav><a href="index.php">Home</a></nav></header><main><p class="tag">NOW PLAYING</p><h1><?=e($ep['anime'])?> — Episode <?=e($ep['episode_number'])?></h1>
<div class="player"><video controls playsinline src="<?=e($ep['video_url'])?>"></video></div><p class="muted"><?=e($ep['title'])?></p></main></body></html>