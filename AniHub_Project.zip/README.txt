ANIHUB - QUICK SETUP
1. Upload the whole folder to a PHP hosting/server with PHP 8+ and SQLite enabled.
2. Make sure the folders uploads/posters and uploads/videos are writable.
3. Open /admin.php
4. Login:
   Username: admin
   Password: anime123
5. Add anime, then add episodes.
6. Change ADMIN_USER and ADMIN_PASS in config.php before putting the site online.

This project is intended for content you have the rights/permission to host.
