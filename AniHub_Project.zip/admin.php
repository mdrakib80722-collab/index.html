<?php
require __DIR__.'/config.php';
if(isset($_GET['logout'])){session_destroy();header('Location:admin.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['login'])){
 if(hash_equals(ADMIN_USER,$_POST['username']??'') && hash_equals(ADMIN_PASS,$_POST['password']??'')){$_SESSION['admin']=true;header('Location:admin.php');exit;}
 $error='Wrong username or password.';
}
if(!logged_in()):
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login</title><link rel="stylesheet" href="assets/style.css"></head><body class="login"><form class="loginbox" method="post"><div class="logo">ANI<span>HUB</span></div><h1>Admin Login</h1><?php if($error):?><div class="error"><?=e($error)?></div><?php endif;?><input name="username" placeholder="Username" required><input type="password" name="password" placeholder="Password" required><button name="login">Login</button><small>Default: admin / anime123</small></form></body></html><?php exit; endif;

if(isset($_POST['add_anime'])){
 $poster=''; if(!empty($_FILES['poster']['name'])){ $ext=strtolower(pathinfo($_FILES['poster']['name'],PATHINFO_EXTENSION)); if(in_array($ext,['jpg','jpeg','png','webp'])){$name=bin2hex(random_bytes(8)).'.'.$ext;move_uploaded_file($_FILES['poster']['tmp_name'],__DIR__.'/uploads/posters/'.$name);$poster='uploads/posters/'.$name;}}
 $s=$db->prepare("INSERT INTO anime(title,description,genre,year,poster) VALUES(?,?,?,?,?)");$s->execute([$_POST['title'],$_POST['description'],$_POST['genre'],(int)$_POST['year'],$poster]);
 header('Location:admin.php');exit;
}
if(isset($_GET['delete_anime'])){$id=(int)$_GET['delete_anime'];$db->prepare("DELETE FROM episodes WHERE anime_id=?")->execute([$id]);$db->prepare("DELETE FROM anime WHERE id=?")->execute([$id]);header('Location:admin.php');exit;}
if(isset($_POST['add_episode'])){
 $video=$_POST['video_url']??'';
 if(!empty($_FILES['video']['name'])){$ext=strtolower(pathinfo($_FILES['video']['name'],PATHINFO_EXTENSION)); if(in_array($ext,['mp4','webm','ogg'])){$name=bin2hex(random_bytes(8)).'.'.$ext;move_uploaded_file($_FILES['video']['tmp_name'],__DIR__.'/uploads/videos/'.$name);$video='uploads/videos/'.$name;}}
 $db->prepare("INSERT INTO episodes(anime_id,episode_number,title,video_url) VALUES(?,?,?,?)")->execute([(int)$_POST['anime_id'],$_POST['episode_number'],$_POST['episode_title'],$video]);header('Location:admin.php');exit;
}
if(isset($_GET['delete_episode'])){$db->prepare("DELETE FROM episodes WHERE id=?")->execute([(int)$_GET['delete_episode']]);header('Location:admin.php');exit;}
$anime=$db->query("SELECT * FROM anime ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin</title><link rel="stylesheet" href="assets/style.css"></head><body>
<header><a class="logo" href="index.php">ANI<span>HUB</span></a><nav><a href="index.php">View Site</a><a href="admin.php?logout=1">Logout</a></nav></header>
<main><div class="adminhead"><div><p class="tag">CONTROL PANEL</p><h1>Anime Manager</h1></div></div>
<div class="forms"><form class="panel" method="post" enctype="multipart/form-data"><h2>Add Anime</h2><input name="title" placeholder="Anime title" required><input name="genre" placeholder="Genre e.g. Action, Fantasy"><input name="year" type="number" value="2026"><textarea name="description" placeholder="Description"></textarea><label>Poster <input type="file" name="poster" accept="image/*"></label><button name="add_anime">Add Anime</button></form>
<form class="panel" method="post" enctype="multipart/form-data"><h2>Add Episode</h2><select name="anime_id" required><option value="">Choose anime</option><?php foreach($anime as $a):?><option value="<?=$a['id']?>"><?=e($a['title'])?></option><?php endforeach;?></select><input name="episode_number" placeholder="Episode number" required><input name="episode_title" placeholder="Episode title"><input name="video_url" placeholder="Video URL (optional)"><label>Or upload video <input type="file" name="video" accept="video/*"></label><button name="add_episode">Add Episode</button></form></div>
<h2>Your Anime</h2><div class="adminlist"><?php foreach($anime as $a):?><div class="adminitem"><div><b><?=e($a['title'])?></b><small><?=e($a['genre'])?></small></div><a class="danger" href="?delete_anime=<?=$a['id']?>" onclick="return confirm('Delete this anime?')">Delete</a></div>
<?php $s=$db->prepare("SELECT * FROM episodes WHERE anime_id=? ORDER BY id DESC");$s->execute([$a['id']]);foreach($s as $ep):?><div class="subitem">↳ EP <?=e($ep['episode_number'])?> — <?=e($ep['title'])?> <a class="danger" href="?delete_episode=<?=$ep['id']?>">Delete</a></div><?php endforeach;endforeach;?></div></main></body></html>