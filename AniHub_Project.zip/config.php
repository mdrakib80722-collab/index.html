<?php
declare(strict_types=1);
session_start();

const SITE_NAME = 'AniHub';
const ADMIN_USER = 'admin';
const ADMIN_PASS = 'anime123';

$db = new PDO('sqlite:' . __DIR__ . '/database.sqlite');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->exec("CREATE TABLE IF NOT EXISTS anime (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 description TEXT DEFAULT '',
 genre TEXT DEFAULT '',
 year INTEGER DEFAULT 2026,
 poster TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
)");
$db->exec("CREATE TABLE IF NOT EXISTS episodes (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 anime_id INTEGER NOT NULL,
 episode_number TEXT NOT NULL,
 title TEXT DEFAULT '',
 video_url TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(anime_id) REFERENCES anime(id) ON DELETE CASCADE
)");

function e(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }
function logged_in(): bool { return isset($_SESSION['admin']); }
function require_login(): void {
    if (!logged_in()) { header('Location: admin.php'); exit; }
}
