<?php
require __DIR__.'/config.php';
$id=(int)($_GET['id']??0);
$s=$db->prepare("SELECT * FROM anime WHERE id=?"); $s->execute([$id]); $a=$s->fetch(PDO::FETCH_ASSOC);
if(!$a){http_response_code(404);exit('Anime not found');}
$s=$db->prepare("SELECT * FROM episodes WHERE anime_id=? ORDER BY CAST(episode_number AS INTEGER), id"); $s->execute([$id]); $eps=$s->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($a['title'])?></title><link rel="stylesheet" href="assets/style.css"></head><body>
<header><a class="logo" href="index.php">ANI<span>HUB</span></a><nav><a href="index.php">Home</a><a href="admin.php">Admin</a></nav></header>
<main class="details"><div class="detail-poster"><?php if($a['poster']):?><img src="<?=e($a['poster'])?>"><?php endif;?></div><div><p class="tag"><?=e($a['genre'])?> • <?=e((string)$a['year'])?></p><h1><?=e($a['title'])?></h1><p class="desc"><?=nl2br(e($a['description']))?></p></div></main>
<section class="episodes"><h2>Episodes</h2><?php if(!$eps):?><p class="muted">No episodes added yet.</p><?php endif;?><?php foreach($eps as $ep):?>
<div class="episode"><div><b>Episode <?=e($ep['episode_number'])?></b><span><?=e($ep['title'])?></span></div><?php if($ep['video_url']):?><a class="btn" href="watch.php?id=<?=$ep['id']?>">Watch</a><?php endif;?></div><?php endforeach;?></section>
</body></html>