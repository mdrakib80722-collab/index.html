<?php
require __DIR__.'/config.php';
$q = trim($_GET['q'] ?? '');
$genre = trim($_GET['genre'] ?? '');
$sql = "SELECT * FROM anime WHERE 1=1";
$params = [];
if ($q !== '') { $sql .= " AND title LIKE ?"; $params[] = "%$q%"; }
if ($genre !== '') { $sql .= " AND genre LIKE ?"; $params[] = "%$genre%"; }
$sql .= " ORDER BY id DESC";
$stmt = $db->prepare($sql); $stmt->execute($params);
$anime = $stmt->fetchAll(PDO::FETCH_ASSOC);
$genres = $db->query("SELECT DISTINCT genre FROM anime WHERE genre<>'' ORDER BY genre")->fetchAll(PDO::FETCH_COLUMN);
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=SITE_NAME?></title><link rel="stylesheet" href="assets/style.css"></head><body>
<header><a class="logo" href="index.php">ANI<span>HUB</span></a>
<nav><a href="index.php">Home</a><a href="admin.php">Admin</a></nav></header>
<section class="hero"><div><p class="tag">ANIME STREAMING HUB</p><h1>Watch your favorite anime.</h1><p>Manage your own authorized anime collection from one simple dashboard.</p>
<form class="search"><input name="q" value="<?=e($q)?>" placeholder="Search anime..."><button>Search</button></form></div></section>
<main><div class="bar"><h2><?= $q ? 'Search results' : 'Latest Anime' ?></h2>
<form><select name="genre" onchange="this.form.submit()"><option value="">All Genres</option><?php foreach($genres as $g): ?><option <?=$genre===$g?'selected':''?>><?=e($g)?></option><?php endforeach;?></select></form></div>
<div class="grid"><?php foreach($anime as $a): ?>
<a class="card" href="anime.php?id=<?=$a['id']?>"><div class="poster"><?php if($a['poster']): ?><img src="<?=e($a['poster'])?>"><?php else: ?><span>NO POSTER</span><?php endif;?></div>
<div class="ct"><h3><?=e($a['title'])?></h3><p><?=e($a['genre'])?> • <?=e((string)$a['year'])?></p></div></a>
<?php endforeach; if(!$anime): ?><div class="empty">No anime found.</div><?php endif;?></div></main>
<footer>© <?=date('Y')?> <?=SITE_NAME?></footer></body></html>